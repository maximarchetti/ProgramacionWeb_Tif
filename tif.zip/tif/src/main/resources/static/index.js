const baseGetUrl = 'http://localhost:8080/facturas-front/traer';
const baseCreateUrl = 'http://localhost:8080/facturas-front/crear';
const baseEditUrl = 'http://localhost:8080/facturas-front/editar';

//Variables Globales
const tablaFacturasHTML = document.getElementById('tablaFacturas');
const fechaEmisionInput = document.getElementById('fechaEmision');
const fechaPagoInput = document.getElementById('fechaPago');
const medioDePagoInput = document.getElementById('medioDePago');
const totalPagoInput = document.getElementById('totalPago');
const btnGuardar = document.getElementById('btnGuardar');
const tituloModal = document.getElementById('tituloModal');
const modal = document.getElementById('myModal');
const btnAbrir = document.getElementById('myBtn');
const spanClose = document.getElementsByClassName('close')[0];

let listaFacturas = [];
let idFacturaModificar = null;

function formatDateForDisplay(isoDate) {
  if (!isoDate) return '';
  const d = new Date(isoDate);
  if (isNaN(d)) return isoDate;
  return d.toLocaleDateString('es-AR');
}

function abrirModalCrear() {
  tituloModal.innerText = 'Crear Factura';
  idFacturaModificar = null;
  resetModal();
  modal.style.display = 'block';
}

function abrirModalEditar(id) {
  const f = listaFacturas.find(x => (x.id === id) || (x.idfactura === id));
  if (!f) { alert('Factura no encontrada en la lista'); return; }
  tituloModal.innerText = 'Modificar Factura';
  idFacturaModificar = id;
  // Mapeo flexible: si tu backend devuelve otros nombres, ajusta aquí
  fechaEmisionInput.value = f.fechaEmision ?? f.fecha_emision ?? f.fecha_emisionfactura ?? '';
  fechaPagoInput.value = f.fechaPago ?? f.fecha_pago ?? f.fecha_pagofactura ?? '';
  medioDePagoInput.value = f.medioDePago ?? f.medio_de_pago ?? f.medio_de_pagofactura ?? '';
  totalPagoInput.value = f.totalPago ?? f.total_pago ?? f.total_pagofactura ?? '';
  modal.style.display = 'block';
}

async function guardarFactura() {
  if (!fechaEmisionInput.value || !fechaPagoInput.value || !medioDePagoInput.value || !totalPagoInput.value) {
    alert('Completar todos los campos');
    return;
  }

  const payload = {
    fechaEmision: fechaEmisionInput.value,
    fechaPago: fechaPagoInput.value,
    medioDePago: medioDePagoInput.value,
    totalPago: parseFloat(totalPagoInput.value)
  };

  try {
    if (idFacturaModificar) {
      const url = `${baseEditUrl}/${idFacturaModificar}`;
      const resp = await fetch(url, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (!resp.ok) throw new Error('Error al modificar factura: ' + resp.status);
      alert('Factura modificada');
    } else {
      const url = baseCreateUrl;
      const resp = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (!resp.ok) throw new Error('Error al crear factura: ' + resp.status);
      alert('Factura creada');
    }
    modal.style.display = 'none';
    resetModal();
    await obtenerFacturas();
  } catch (err) {
    console.error(err);
    alert('Error al guardar la factura. Revisá la consola.');
  }
}

async function obtenerFacturas() {
  tablaFacturasHTML.innerHTML = '';
  try {
    const resp = await fetch(baseGetUrl);
    if (!resp.ok) throw new Error('Error al obtener facturas: ' + resp.status);
    const facturas = await resp.json();
    listaFacturas = facturas;
    renderTabla(facturas);
  } catch (err) {
    console.error(err);
    alert('Error en el listado de facturas');
  }
}

function renderTabla(facturas) {
  tablaFacturasHTML.innerHTML = '';
  for (const factura of facturas) {
    const id = factura.id ?? factura.idfactura ?? '';
    const fechaEmision = factura.fechaEmision ?? factura.fecha_emision ?? factura.fecha_emisionfactura ?? '';
    const fechaPago = factura.fechaPago ?? factura.fecha_pago ?? factura.fecha_pagofactura ?? '';
    const medio = factura.medioDePago ?? factura.medio_de_pago ?? factura.medio_de_pagofactura ?? '';
    const total = factura.totalPago ?? factura.total_pago ?? factura.total_pagofactura ?? '';

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <th scope="row">${id}</th>
      <td>${formatDateForDisplay(fechaEmision)}</td>
      <td>${formatDateForDisplay(fechaPago)}</td>
      <td>${medio}</td>
      <td>${total}</td>
      <td>
        <button class="btn btn-outline-success btn-sm" onclick="abrirModalEditar(${id})">Modificar</button>
      </td>
    `;
    tablaFacturasHTML.appendChild(tr);
  }
}

function resetModal() {
  fechaEmisionInput.value = '';
  fechaPagoInput.value = '';
  medioDePagoInput.value = '';
  totalPagoInput.value = '';
}

btnAbrir.addEventListener('click', abrirModalCrear);
spanClose.addEventListener('click', () => { modal.style.display = 'none'; resetModal(); });
window.addEventListener('click', (e) => { if (e.target === modal) { modal.style.display = 'none'; resetModal(); } });
btnGuardar.addEventListener('click', guardarFactura);

window.abrirModalEditar = abrirModalEditar;

obtenerFacturas();
