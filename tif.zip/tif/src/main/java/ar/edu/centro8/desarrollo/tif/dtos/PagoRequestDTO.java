package ar.edu.centro8.desarrollo.tif.dtos;

import java.math.BigDecimal;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class PagoRequestDTO {

    private BigDecimal totalPago;
    private Date fechaPago;
    private Long idMedioDePago;

    public PagoRequestDTO() { }
    public PagoRequestDTO(BigDecimal totalPago, Date fechaPago, Long idMedioDePago) {
        this.totalPago = totalPago;
        this.fechaPago = fechaPago;
        this.idMedioDePago = idMedioDePago;
    }

    public void validarTotalPago() {
        if (this.totalPago == null || this.totalPago.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("El total del pago debe ser mayor a cero.");
        }
    }
    public void validarMedio() {
        if (this.idMedioDePago == null || this.idMedioDePago <= 0) {
            throw new IllegalArgumentException("El ID de medio de pago es obligatorio.");
        }
    }
    public void validar() { validarTotalPago(); validarMedio(); }
}
