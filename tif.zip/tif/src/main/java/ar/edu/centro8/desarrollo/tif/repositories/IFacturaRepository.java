package ar.edu.centro8.desarrollo.tif.repositories;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import ar.edu.centro8.desarrollo.tif.models.Factura;

public interface IFacturaRepository extends JpaRepository<Factura, Long> {

    @Query("SELECT f FROM Factura f WHERE f.pago.totalPago = ?1")
    List<Factura> findByTotalPago(BigDecimal totalPago);

    @Query("SELECT f FROM Factura f WHERE f.pago.fechaPago = ?1")
    List<Factura> findByFechaPago(Date fechaPago);
}