package ar.edu.centro8.desarrollo.tif.repositories;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import ar.edu.centro8.desarrollo.tif.models.MedioDePago;

public interface IMedioDePagoRepository extends JpaRepository<MedioDePago, Long> {
    Optional<MedioDePago> findByNombre(String nombre);
}