package ar.edu.centro8.desarrollo.tif.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import ar.edu.centro8.desarrollo.tif.models.Pago;

public interface IPagoRepository extends JpaRepository<Pago, Long> { }