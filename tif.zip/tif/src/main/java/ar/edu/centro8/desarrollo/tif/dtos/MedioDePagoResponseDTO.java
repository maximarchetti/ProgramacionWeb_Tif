package ar.edu.centro8.desarrollo.tif.dtos;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class MedioDePagoResponseDTO {

    private Long id;
    private String nombre;

    public MedioDePagoResponseDTO() { }
    public MedioDePagoResponseDTO(Long id, String nombre) { this.id = id; this.nombre = nombre; }
}