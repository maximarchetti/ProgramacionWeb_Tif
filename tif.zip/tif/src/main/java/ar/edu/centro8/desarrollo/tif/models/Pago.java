package ar.edu.centro8.desarrollo.tif.models;

import java.math.BigDecimal;
import java.util.Date;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "pagos")
@NoArgsConstructor
@Getter @Setter
public class Pago {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_pago")
    private Long id;

    @Column(name = "total_pago", nullable = false)
    private BigDecimal totalPago;

    @Temporal(TemporalType.DATE)
    @Column(name = "fecha_pago", nullable = false)
    private Date fechaPago;

    @ManyToOne(optional = false)
    @JoinColumn(name = "id_medio_de_pago", referencedColumnName = "id_medio_de_pago", nullable = false)
    private MedioDePago medioDePago;

    // Relación 1:1 inversa  
    @OneToOne(mappedBy = "pago", orphanRemoval = true)
    @JsonIgnore
    private Factura factura;

    public Pago(BigDecimal totalPago, Date fechaPago, MedioDePago medioDePago) {
        this.totalPago = totalPago;
        this.fechaPago = fechaPago;
        this.medioDePago = medioDePago;
    }

    @Override
    public int hashCode() { return (id == null) ? 0 : id.hashCode(); }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Pago other = (Pago) obj;
        return id != null && id.equals(other.id);
    }
}
