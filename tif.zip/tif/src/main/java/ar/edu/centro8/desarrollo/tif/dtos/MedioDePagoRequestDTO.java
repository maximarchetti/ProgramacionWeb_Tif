package ar.edu.centro8.desarrollo.tif.dtos;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class MedioDePagoRequestDTO {

    private String nombre;

    public MedioDePagoRequestDTO() { }
    public MedioDePagoRequestDTO(String nombre) { this.nombre = nombre; }

    public void validarNombre() {
        if (this.nombre == null || this.nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre del medio de pago no puede estar vacío ni ser nulo.");
        }
        this.nombre = nombre.trim();
    }
    public void validar() { validarNombre(); }
}