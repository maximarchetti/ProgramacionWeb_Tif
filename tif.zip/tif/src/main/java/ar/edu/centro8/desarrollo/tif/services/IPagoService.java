package ar.edu.centro8.desarrollo.tif.services;

import java.util.List;
import ar.edu.centro8.desarrollo.tif.dtos.PagoRequestDTO;
import ar.edu.centro8.desarrollo.tif.dtos.PagoResponseDTO;

public interface IPagoService {
List<PagoResponseDTO> getPagos();
    PagoResponseDTO savePago(PagoRequestDTO pagoDTO);
    void deletePago(Long id);
    PagoResponseDTO findPago(Long id);
    PagoResponseDTO editPago(Long id, PagoRequestDTO pagoDTO);
} 