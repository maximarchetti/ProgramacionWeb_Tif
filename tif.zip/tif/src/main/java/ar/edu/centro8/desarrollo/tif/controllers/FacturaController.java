package ar.edu.centro8.desarrollo.tif.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import ar.edu.centro8.desarrollo.tif.dtos.FacturaRequestDTO;
import ar.edu.centro8.desarrollo.tif.dtos.FacturaResponseDTO;
import ar.edu.centro8.desarrollo.tif.services.IFacturaService;

@RestController
@CrossOrigin(origins = "*")
public class FacturaController {
@Autowired
    private IFacturaService facturaServ;

    @GetMapping("/facturas/traer")
    public ResponseEntity<List<FacturaResponseDTO>> getFacturas() {
        return ResponseEntity.ok(facturaServ.getFacturas());
    }

    @PostMapping("/facturas/crear")
    public ResponseEntity<?> saveFactura(@RequestBody FacturaRequestDTO facturaDTO) {
        try {
            FacturaResponseDTO facturaCreada = facturaServ.saveFactura(facturaDTO);
            return ResponseEntity.status(HttpStatus.CREATED).body(facturaCreada);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @GetMapping("/facturas/traer/{id}")
    public ResponseEntity<?> getFactura(@PathVariable Long id) {
        try {
            FacturaResponseDTO factura = facturaServ.findFactura(id);
            return ResponseEntity.ok(factura);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Factura no encontrada");
        }
    }

    @PatchMapping("/facturas/editar/{id}")
    public ResponseEntity<?> editFactura(@PathVariable Long id, @RequestBody FacturaRequestDTO facturaDTO) {
        try {
            FacturaResponseDTO facturaEditada = facturaServ.editFactura(id, facturaDTO);
            return ResponseEntity.ok(facturaEditada);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }
}