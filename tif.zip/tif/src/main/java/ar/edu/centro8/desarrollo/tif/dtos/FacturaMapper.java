package ar.edu.centro8.desarrollo.tif.dtos;

import ar.edu.centro8.desarrollo.tif.models.Factura;
import ar.edu.centro8.desarrollo.tif.models.Pago;
import org.springframework.stereotype.Component;
import lombok.RequiredArgsConstructor;
import ar.edu.centro8.desarrollo.tif.repositories.IPagoRepository;

@Component
@RequiredArgsConstructor
public class FacturaMapper {

    private final IPagoRepository pagoRepository;

    public Factura toEntity(FacturaRequestDTO dto) {
        Factura factura = new Factura();
        factura.setFechaEmision(dto.getFechaEmision());

        Pago pago = pagoRepository.findById(dto.getIdPago())
                .orElseThrow(() -> new RuntimeException("Pago no encontrado"));
        factura.setPago(pago);
        return factura;
    }

    public FacturaResponseDTO toResponseDTO(Factura factura) {
        return new FacturaResponseDTO(factura.getId(), factura.getFechaEmision());
    }
}