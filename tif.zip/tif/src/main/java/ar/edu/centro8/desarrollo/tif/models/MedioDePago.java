package ar.edu.centro8.desarrollo.tif.models;

import java.util.HashSet;
import java.util.Set;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "medios_de_pago")
@NoArgsConstructor
@Getter @Setter
public class MedioDePago {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_medio_de_pago")
    private Long id;

    @Column(name = "nombre", nullable = false, unique = true)
    private String nombre;

    // Relación 1:N con Pago 
    @OneToMany(mappedBy = "medioDePago")
    @JsonIgnore
    private Set<Pago> pagos = new HashSet<>();

    public MedioDePago(String nombre) {
        this.nombre = nombre;
    }

    public Pago agregarPago(Pago pago) {
        this.pagos.add(pago);
        return pago;
    }

    @Override
    public int hashCode() { return (id == null) ? 0 : id.hashCode(); }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        MedioDePago other = (MedioDePago) obj;
        return id != null && id.equals(other.id);
    }
}