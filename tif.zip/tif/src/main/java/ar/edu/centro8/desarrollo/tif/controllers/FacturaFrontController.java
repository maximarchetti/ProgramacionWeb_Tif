package ar.edu.centro8.desarrollo.tif.controllers;

import java.math.BigDecimal;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import ar.edu.centro8.desarrollo.tif.models.Factura;
import ar.edu.centro8.desarrollo.tif.models.Pago;
import ar.edu.centro8.desarrollo.tif.models.MedioDePago;
import ar.edu.centro8.desarrollo.tif.repositories.IFacturaRepository;
import ar.edu.centro8.desarrollo.tif.repositories.IPagoRepository;
import ar.edu.centro8.desarrollo.tif.repositories.IMedioDePagoRepository;

@RestController
@CrossOrigin(origins = "*", methods = { RequestMethod.GET, RequestMethod.POST, RequestMethod.PATCH, RequestMethod.PUT, RequestMethod.DELETE })
@RequestMapping("/facturas-front")
public class FacturaFrontController {

    @Autowired
    private IFacturaRepository facturaRepository;

    @Autowired
    private IPagoRepository pagoRepository;

    @Autowired
    private IMedioDePagoRepository medioDePagoRepository;

    @GetMapping("/traer")
    public ResponseEntity<?> getAllFacturas() {
        try {
            return ResponseEntity.ok(facturaRepository.findAll());
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error al obtener facturas");
        }
    }

    @PostMapping("/crear")
    public ResponseEntity<?> crearFacturaDesdePlano(@RequestBody Map<String, Object> payload) {
        try {
            String fechaEmisionStr = payload.get("fechaEmision") == null ? null : payload.get("fechaEmision").toString();
            String fechaPagoStr = payload.get("fechaPago") == null ? null : payload.get("fechaPago").toString();
            String medioNombre = payload.get("medioDePago") == null ? null : payload.get("medioDePago").toString();

            Object totalObj = payload.get("totalPago");
            if (totalObj == null) return ResponseEntity.badRequest().body("totalPago es requerido");
            BigDecimal total;
            try { total = new BigDecimal(totalObj.toString()); }
            catch (NumberFormatException nfe) { return ResponseEntity.badRequest().body("totalPago inválido"); }

            java.sql.Date fechaEmision = (fechaEmisionStr == null || fechaEmisionStr.isBlank()) ? null
                    : java.sql.Date.valueOf(java.time.LocalDate.parse(fechaEmisionStr));
            java.sql.Date fechaPago = (fechaPagoStr == null || fechaPagoStr.isBlank()) ? null
                    : java.sql.Date.valueOf(java.time.LocalDate.parse(fechaPagoStr));

            if (medioNombre == null || medioNombre.isBlank()) return ResponseEntity.badRequest().body("medioDePago es requerido");

            Optional<MedioDePago> optMed = medioDePagoRepository.findByNombre(medioNombre);
            MedioDePago medio = optMed.orElseGet(() -> medioDePagoRepository.save(new MedioDePago(medioNombre)));

            Pago pago = new Pago(total, fechaPago, medio);
            pago = pagoRepository.save(pago);

            Factura factura = new Factura(fechaEmision, pago);
            factura = facturaRepository.save(factura);

            return ResponseEntity.status(HttpStatus.CREATED).body(factura);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error al crear factura: " + e.getMessage());
        }
    }
}