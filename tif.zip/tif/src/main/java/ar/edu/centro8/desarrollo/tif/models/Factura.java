package ar.edu.centro8.desarrollo.tif.models;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
 
@Entity
@Table(name = "facturas", uniqueConstraints = {
    @UniqueConstraint(name = "uk_factura_pago", columnNames = {"id_pago"})
})
@Getter @Setter
@NoArgsConstructor
public class Factura {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_factura")
    private Long id;

    @Temporal(TemporalType.DATE)
    @Column(name = "fecha_emision", nullable = false)
    private Date fechaEmision;

    @OneToOne(optional = false)
    @JoinColumn(name = "id_pago", referencedColumnName = "id_pago", nullable = false, unique = true)
    private Pago pago;

    public Factura(Date fechaEmision, Pago pago) {
        this.fechaEmision = fechaEmision;
        this.pago = pago;
    }

    @Override
    public int hashCode() { return (id == null) ? 0 : id.hashCode(); }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Factura other = (Factura) obj;
        return id != null && id.equals(other.id);
    }
/* ---------------------------
       Getters JSON para el front
       --------------------------- */

        @JsonProperty("id")
        public Long getIdJson() {
            return this.id;
        }

        @JsonProperty("fechaEmision")
        @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
        public Date getFechaEmisionJson() {
            return this.fechaEmision;
        }

        @JsonProperty("fechaPago")
        @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
        public Date getFechaPagoJson() {
            return (this.pago != null) ? this.pago.getFechaPago() : null;
        }

        @JsonProperty("medioDePago")
        public String getMedioDePagoJson() {
            if (this.pago == null) return null;
            MedioDePago mdp = this.pago.getMedioDePago();
            return (mdp != null) ? mdp.getNombre() : null;
        }

        @JsonProperty("totalPago")
        public Double getTotalPagoJson() {
            if (this.pago == null || this.pago.getTotalPago() == null) return null;
            return this.pago.getTotalPago().doubleValue();
        }
}