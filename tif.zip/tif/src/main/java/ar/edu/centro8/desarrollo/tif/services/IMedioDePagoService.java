package ar.edu.centro8.desarrollo.tif.services;

import java.util.List;
import ar.edu.centro8.desarrollo.tif.dtos.MedioDePagoRequestDTO;
import ar.edu.centro8.desarrollo.tif.dtos.MedioDePagoResponseDTO;

public interface IMedioDePagoService {
 List<MedioDePagoResponseDTO> getMediosDePago();
    MedioDePagoResponseDTO saveMedioDePago(MedioDePagoRequestDTO medioDePagoDTO);
    void deleteMedioDePago(Long id);
    MedioDePagoResponseDTO findMedioDePago(Long id);
    MedioDePagoResponseDTO editMedioDePago(Long id, MedioDePagoRequestDTO medioDePagoDTO);
}