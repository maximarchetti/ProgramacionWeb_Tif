package ar.edu.centro8.desarrollo.tif.services;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ar.edu.centro8.desarrollo.tif.dtos.FacturaMapper;
import ar.edu.centro8.desarrollo.tif.dtos.FacturaRequestDTO;
import ar.edu.centro8.desarrollo.tif.dtos.FacturaResponseDTO;
import ar.edu.centro8.desarrollo.tif.models.Factura;
import ar.edu.centro8.desarrollo.tif.models.Pago;
import ar.edu.centro8.desarrollo.tif.repositories.IFacturaRepository;
import ar.edu.centro8.desarrollo.tif.repositories.IPagoRepository;
import jakarta.transaction.Transactional;

@Transactional
@Service
public class FacturaService implements IFacturaService {

    @Autowired private IFacturaRepository facturaRepo;
    @Autowired private IPagoRepository pagoRepo;
    @Autowired private FacturaMapper facturaMapper;

    @Override
    public List<FacturaResponseDTO> getFacturas() {
        return facturaRepo.findAll().stream()
                .map(facturaMapper::toResponseDTO)
                .collect(Collectors.toList());
    }

    @Override
    public FacturaResponseDTO saveFactura(FacturaRequestDTO facturaDTO) {
        facturaDTO.validar();

        Pago pago = pagoRepo.findById(facturaDTO.getIdPago())
                .orElseThrow(() -> new RuntimeException("Pago no encontrado"));

        // Regla: impedir emitir factura si el pago ya tiene factura
        if (pago.getFactura() != null) {
            throw new IllegalArgumentException("El pago ya tiene una factura asociada.");
        }

        Factura factura = new Factura();
        factura.setFechaEmision(facturaDTO.getFechaEmision());
        factura.setPago(pago);

        Factura facturaGuardada = facturaRepo.save(factura);
        return facturaMapper.toResponseDTO(facturaGuardada);
    }

    
    @Override
    public FacturaResponseDTO findFactura(Long id) {
        return facturaRepo.findById(id)
                .map(facturaMapper::toResponseDTO)
                .orElseThrow(() -> new RuntimeException("Factura no encontrada"));
    }

    @Override
    public FacturaResponseDTO editFactura(Long id, FacturaRequestDTO facturaDTO) {
        facturaDTO.validar();

        Factura factura = facturaRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Factura no encontrada"));

        Pago nuevoPago = pagoRepo.findById(facturaDTO.getIdPago())
                .orElseThrow(() -> new RuntimeException("Pago no encontrado"));

        // Regla: asegurar 1:1 (no reasignar a un pago que ya tenga otra factura)
        if (nuevoPago.getFactura() != null && !nuevoPago.getFactura().getId().equals(factura.getId())) {
            throw new IllegalArgumentException("El pago seleccionado ya tiene otra factura.");
        }

        factura.setFechaEmision(facturaDTO.getFechaEmision());
        factura.setPago(nuevoPago);

        Factura facturaActualizada = facturaRepo.save(factura);
        return facturaMapper.toResponseDTO(facturaActualizada);
    }
}
