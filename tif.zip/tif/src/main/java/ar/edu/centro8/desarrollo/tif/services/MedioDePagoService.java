package ar.edu.centro8.desarrollo.tif.services;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ar.edu.centro8.desarrollo.tif.dtos.MedioDePagoMapper;
import ar.edu.centro8.desarrollo.tif.dtos.MedioDePagoRequestDTO;
import ar.edu.centro8.desarrollo.tif.dtos.MedioDePagoResponseDTO;
import ar.edu.centro8.desarrollo.tif.models.MedioDePago;
import ar.edu.centro8.desarrollo.tif.repositories.IMedioDePagoRepository;
import jakarta.transaction.Transactional;

@Transactional
@Service
public class MedioDePagoService implements IMedioDePagoService {

    @Autowired
    private IMedioDePagoRepository medioRepo;

    @Override
    public List<MedioDePagoResponseDTO> getMediosDePago() {
        return medioRepo.findAll().stream()
                .map(MedioDePagoMapper::toResponseDTO)
                .collect(Collectors.toList());
    }

    @Override
    public MedioDePagoResponseDTO saveMedioDePago(MedioDePagoRequestDTO medioDePagoDTO) {
        medioDePagoDTO.validar();
        // Regla: no duplicar nombre
        medioRepo.findByNombre(medioDePagoDTO.getNombre())
                 .ifPresent(m -> { throw new IllegalArgumentException("El medio de pago ya existe"); });

        MedioDePago medioDePago = MedioDePagoMapper.toEntity(medioDePagoDTO);
        medioDePago = medioRepo.saveAndFlush(medioDePago);
        return MedioDePagoMapper.toResponseDTO(medioDePago);
    }

    @Override
    public void deleteMedioDePago(Long id) {
        MedioDePago medio = medioRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("El medio de pago no existe"));
        // Regla de negocio: no se puede eliminar si tiene pagos asociados
        if (medio.getPagos() != null && !medio.getPagos().isEmpty()) {
            throw new IllegalArgumentException("No se puede eliminar un MedioDePago con Pagos asociados.");
        }
        medioRepo.delete(medio);
    }

    @Override
    public MedioDePagoResponseDTO findMedioDePago(Long id) {
        return medioRepo.findById(id)
                .map(MedioDePagoMapper::toResponseDTO)
                .orElseThrow(() -> new RuntimeException("Medio de pago no encontrado"));
    }

    @Override
    public MedioDePagoResponseDTO editMedioDePago(Long id, MedioDePagoRequestDTO medioDePagoDTO) {
        medioDePagoDTO.validar();
        MedioDePago medio = medioRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Medio de pago no encontrado"));
        // Regla: evitar duplicar nombre al editar
        medioRepo.findByNombre(medioDePagoDTO.getNombre())
                 .filter(m -> !m.getId().equals(id))
                 .ifPresent(m -> { throw new IllegalArgumentException("Ya existe un medio con ese nombre."); });

        MedioDePagoMapper.updateEntity(medio, medioDePagoDTO);
        MedioDePago medioActualizado = medioRepo.save(medio);
        return MedioDePagoMapper.toResponseDTO(medioActualizado);
    }
}
