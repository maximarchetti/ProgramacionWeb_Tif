package ar.edu.centro8.desarrollo.tif.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import ar.edu.centro8.desarrollo.tif.dtos.PagoRequestDTO;
import ar.edu.centro8.desarrollo.tif.dtos.PagoResponseDTO;
import ar.edu.centro8.desarrollo.tif.services.IPagoService;

@RestController
@CrossOrigin(origins = "*")
public class PagoController {
@Autowired
    private IPagoService pagoServ;

    @GetMapping("/pagos/traer")
    public ResponseEntity<List<PagoResponseDTO>> getPagos() {
        return ResponseEntity.ok(pagoServ.getPagos());
    }

    @PostMapping("/pagos/crear")
    public ResponseEntity<?> savePago(@RequestBody PagoRequestDTO pagoDTO) {
        try {
            PagoResponseDTO pagoCreado = pagoServ.savePago(pagoDTO);
            return ResponseEntity.status(HttpStatus.CREATED).body(pagoCreado);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Medio de pago no encontrado");
        }
    }

    @GetMapping("/pagos/traer/{id}")
    public ResponseEntity<?> getPago(@PathVariable Long id) {
        try {
            PagoResponseDTO pago = pagoServ.findPago(id);
            return ResponseEntity.ok(pago);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Pago no encontrado");
        }
    }

    @DeleteMapping("/pagos/borrar/{id}")
    public ResponseEntity<?> deletePago(@PathVariable Long id) {
        try {
            pagoServ.deletePago(id);
            return ResponseEntity.ok().body("Pago eliminado correctamente");
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Error: " + e.getMessage());
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Pago no encontrado");
        }
    }

    @PatchMapping("/pagos/editar/{id}")
    public ResponseEntity<?> editPago(@PathVariable Long id, @RequestBody PagoRequestDTO pagoDTO) {
        try {
            PagoResponseDTO pagoEditado = pagoServ.editPago(id, pagoDTO);
            return ResponseEntity.ok(pagoEditado);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }
}
