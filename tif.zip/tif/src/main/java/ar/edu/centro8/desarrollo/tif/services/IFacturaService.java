package ar.edu.centro8.desarrollo.tif.services;

import java.util.List;
import ar.edu.centro8.desarrollo.tif.dtos.FacturaRequestDTO;
import ar.edu.centro8.desarrollo.tif.dtos.FacturaResponseDTO;

public interface IFacturaService {
 List<FacturaResponseDTO> getFacturas();
    FacturaResponseDTO saveFactura(FacturaRequestDTO facturaDTO);
    FacturaResponseDTO findFactura(Long id);
    FacturaResponseDTO editFactura(Long id, FacturaRequestDTO facturaDTO);
}