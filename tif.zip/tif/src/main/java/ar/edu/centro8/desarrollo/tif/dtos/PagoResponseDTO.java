package ar.edu.centro8.desarrollo.tif.dtos;

import java.math.BigDecimal;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class PagoResponseDTO {
private Long id;
    private BigDecimal totalPago;
    private Date fechaPago;

    public PagoResponseDTO() { }
    public PagoResponseDTO(Long id, BigDecimal totalPago, Date fechaPago) {
        this.id = id;
        this.totalPago = totalPago;
        this.fechaPago = fechaPago;
    }
}