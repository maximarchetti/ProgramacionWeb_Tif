package ar.edu.centro8.desarrollo.tif.dtos;

import ar.edu.centro8.desarrollo.tif.models.MedioDePago;

public class MedioDePagoMapper {

public static MedioDePago toEntity(MedioDePagoRequestDTO dto) {
        MedioDePago medioDePago = new MedioDePago();
        medioDePago.setNombre(dto.getNombre());
        return medioDePago;
    }

    public static MedioDePagoResponseDTO toResponseDTO(MedioDePago medioDePago) {
        return new MedioDePagoResponseDTO(medioDePago.getId(), medioDePago.getNombre());
    }

    public static void updateEntity(MedioDePago medioDePago, MedioDePagoRequestDTO dto) {
        medioDePago.setNombre(dto.getNombre());
    }
}