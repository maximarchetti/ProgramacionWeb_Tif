package ar.edu.centro8.desarrollo.tif.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import ar.edu.centro8.desarrollo.tif.dtos.MedioDePagoRequestDTO;
import ar.edu.centro8.desarrollo.tif.dtos.MedioDePagoResponseDTO;
import ar.edu.centro8.desarrollo.tif.services.IMedioDePagoService;

@RestController
@CrossOrigin(origins = "*")
public class MedioDePagoController {
@Autowired
    private IMedioDePagoService medioServ;

    @GetMapping("/medios-de-pago/traer")
    public ResponseEntity<List<MedioDePagoResponseDTO>> getMediosDePago() {
        List<MedioDePagoResponseDTO> medios = medioServ.getMediosDePago();
        return ResponseEntity.ok(medios);
    }

    @PostMapping("/medios-de-pago/crear")
    public ResponseEntity<?> saveMedioDePago(@RequestBody MedioDePagoRequestDTO medioDePagoDTO) {
        try {
            MedioDePagoResponseDTO medioCreado = medioServ.saveMedioDePago(medioDePagoDTO);
            return ResponseEntity.status(HttpStatus.CREATED).body(medioCreado);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        }
    }

    @GetMapping("/medios-de-pago/traer/{id}")
    public ResponseEntity<?> getMedioDePago(@PathVariable Long id) {
        try {
            MedioDePagoResponseDTO medio = medioServ.findMedioDePago(id);
            return ResponseEntity.ok(medio);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Medio de pago no encontrado");
        }
    }

    @DeleteMapping("/medios-de-pago/borrar/{id}")
    public ResponseEntity<?> deleteMedioDePago(@PathVariable Long id) {
        try {
            medioServ.deleteMedioDePago(id);
            return ResponseEntity.ok().body("Medio de pago eliminado correctamente.");
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Error: " + e.getMessage());
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Medio de pago no encontrado");
        }
    }

    @PatchMapping("/medios-de-pago/editar/{id}")
    public ResponseEntity<?> editMedioDePago(@PathVariable Long id, @RequestBody MedioDePagoRequestDTO medioDePagoDTO) {
        try {
            MedioDePagoResponseDTO medioEditado = medioServ.editMedioDePago(id, medioDePagoDTO);
            return ResponseEntity.ok(medioEditado);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Medio de pago no encontrado");
        }
    }
}