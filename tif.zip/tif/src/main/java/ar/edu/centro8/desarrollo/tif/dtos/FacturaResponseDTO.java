package ar.edu.centro8.desarrollo.tif.dtos;

import java.util.Date;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class FacturaResponseDTO {
private Long id;
    private Date fechaEmision;

    public FacturaResponseDTO() { }
    public FacturaResponseDTO(Long id, Date fechaEmision) {
        this.id = id;
        this.fechaEmision = fechaEmision;
    }
}