package ar.edu.centro8.desarrollo.tif.dtos;

import org.springframework.stereotype.Component;
import lombok.RequiredArgsConstructor;
import ar.edu.centro8.desarrollo.tif.models.MedioDePago;
import ar.edu.centro8.desarrollo.tif.models.Pago;
import ar.edu.centro8.desarrollo.tif.repositories.IMedioDePagoRepository;

@Component
@RequiredArgsConstructor
public class PagoMapper {
private final IMedioDePagoRepository medioDePagoRepository;

    public Pago toEntity(PagoRequestDTO dto) {
        Pago pago = new Pago();
        pago.setTotalPago(dto.getTotalPago());
        pago.setFechaPago(dto.getFechaPago());

        MedioDePago medio = medioDePagoRepository.findById(dto.getIdMedioDePago())
                .orElseThrow(() -> new RuntimeException("Medio de pago no encontrado"));

        pago.setMedioDePago(medio);
        return pago;
    }

    public PagoResponseDTO toResponseDTO(Pago pago) {
        return new PagoResponseDTO(pago.getId(), pago.getTotalPago(), pago.getFechaPago());
    }
}