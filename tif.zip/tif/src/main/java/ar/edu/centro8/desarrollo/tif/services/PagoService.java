package ar.edu.centro8.desarrollo.tif.services;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ar.edu.centro8.desarrollo.tif.dtos.PagoMapper;
import ar.edu.centro8.desarrollo.tif.dtos.PagoRequestDTO;
import ar.edu.centro8.desarrollo.tif.dtos.PagoResponseDTO;
import ar.edu.centro8.desarrollo.tif.models.MedioDePago;
import ar.edu.centro8.desarrollo.tif.models.Pago;
import ar.edu.centro8.desarrollo.tif.repositories.IMedioDePagoRepository;
import ar.edu.centro8.desarrollo.tif.repositories.IPagoRepository;
import jakarta.transaction.Transactional;

@Transactional
@Service
public class PagoService implements IPagoService {

    @Autowired private IPagoRepository pagoRepo;
    @Autowired private IMedioDePagoRepository medioRepo;
    @Autowired private PagoMapper pagoMapper;

    @Override
    public List<PagoResponseDTO> getPagos() {
        return pagoRepo.findAll().stream()
                .map(pagoMapper::toResponseDTO)
                .collect(Collectors.toList());
    }

    @Override
    public PagoResponseDTO savePago(PagoRequestDTO pagoDTO) {
        pagoDTO.validar();
        validarTotalNoNegativo(pagoDTO);

        // Validar medio existente
        MedioDePago medio = medioRepo.findById(pagoDTO.getIdMedioDePago())
                .orElseThrow(() -> new RuntimeException("Medio de pago no encontrado"));

        Pago pago = new Pago();
        pago.setTotalPago(pagoDTO.getTotalPago());
        pago.setFechaPago(pagoDTO.getFechaPago());
        pago.setMedioDePago(medio);

        Pago pagoGuardado = pagoRepo.save(pago);
        return pagoMapper.toResponseDTO(pagoGuardado);
    }

    @Override
    public void deletePago(Long id) {
        Pago pago = pagoRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("El pago no existe"));
        // Regla: no permitir borrar pago si tiene factura asociada
        if (pago.getFactura() != null) {
            throw new IllegalArgumentException("No se puede eliminar un Pago con Factura asociada.");
        }
        pagoRepo.delete(pago);
    }

    @Override
    public PagoResponseDTO findPago(Long id) {
        return pagoRepo.findById(id)
                .map(pagoMapper::toResponseDTO)
                .orElseThrow(() -> new RuntimeException("Pago no encontrado"));
    }

    @Override
    public PagoResponseDTO editPago(Long id, PagoRequestDTO pagoDTO) {
        pagoDTO.validar();
        validarTotalNoNegativo(pagoDTO);

        Pago pago = pagoRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Pago no encontrado"));

        MedioDePago medio = medioRepo.findById(pagoDTO.getIdMedioDePago())
                .orElseThrow(() -> new RuntimeException("Medio de pago no encontrado"));

        pago.setTotalPago(pagoDTO.getTotalPago());
        pago.setFechaPago(pagoDTO.getFechaPago());
        pago.setMedioDePago(medio);

        Pago pagoActualizado = pagoRepo.save(pago);
        return pagoMapper.toResponseDTO(pagoActualizado);
    }

    private void validarTotalNoNegativo(PagoRequestDTO pagoDTO) {
        if (pagoDTO.getTotalPago().compareTo(java.math.BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("El total del pago no puede ser negativo.");
        }
    }
}