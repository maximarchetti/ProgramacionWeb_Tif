package ar.edu.centro8.desarrollo.tif.dtos;

import java.util.Date;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class FacturaRequestDTO {

    private Date fechaEmision;
    private Long idPago;

    public FacturaRequestDTO() { }
    public FacturaRequestDTO(Date fechaEmision, Long idPago) {
        this.fechaEmision = fechaEmision;
        this.idPago = idPago;
    }

    public void validarFechaEmision() {
        if (fechaEmision == null) {
            throw new IllegalArgumentException("La fecha de emisión es obligatoria.");
        }
        if (fechaEmision.after(new Date())) {
            throw new IllegalArgumentException("La fecha de emisión no puede ser futura.");
        }
    }

    public void validarPagoId() {
        if (idPago == null || idPago <= 0) {
            throw new IllegalArgumentException("El ID de pago es obligatorio.");
        }
    }

    public void validar() { validarFechaEmision(); validarPagoId(); }
}